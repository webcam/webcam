<?php
error_reporting(0);
header('Content-Type:text/html;charset=GB2312');
include_once("../config/pay_config.php");
include_once("../eka/class.ekapay.php");
$ekapay = new ekapay();
$ekapay->parter 		= $eka_merchant_id;		//�̼�Id
$ekapay->key 			= $eka_merchant_key;	//�̼���Կ

$result	= $ekapay->search($_POST['order_id']);

$data = '{"success": "'.$result.'","message": "'. $ekapay->message .'"}';
die($data);
?>